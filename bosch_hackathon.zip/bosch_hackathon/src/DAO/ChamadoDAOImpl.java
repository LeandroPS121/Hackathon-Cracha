/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import CONEXAO_BANCO.Banco_dados;
import OBJECTS.Terceirizado;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.sql.*;

/**
 *
 * @author olf5jvl
 */
public class ChamadoDAOImpl implements ChamadoDAO {

    Banco_dados bd = new Banco_dados();

    /**
     *
     * @param edv
     * @param badgeCode
     * @param expTime
     * @param type
     * @param desc
     * @param status
     * @param locAccess
     * @param idTerceirizado
     */
    @Override
    public void sendChamado(String edv, String badgeCode, int expTime, String type, String desc, String status, String locAccess, String idTerceirizado) {

        LocalDateTime agora = LocalDateTime.now();

        LocalDateTime novaDataHora = agora.plus(expTime, ChronoUnit.YEARS);
        if (edv != null) {
            novaDataHora = agora.plus(expTime, ChronoUnit.HOURS);
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String dataHoraFormatada = novaDataHora.format(formatter);

        String query = "INSERT INTO chamado ("
                + "dataChamado,tipoChamado,descricaoChamado,statusChamado,edvChamado,crachaSelecionadoChamado,locaisSelecionadoChamado,fk_idTerceirizado)"
                + " VALUES (?,?,?,?,?,?,?,?)";

        if (bd.getConnection()) {
            try {
                PreparedStatement stmt = bd.conexao.prepareStatement(query);
                stmt.setString(1, dataHoraFormatada);
                stmt.setString(2, type);
                stmt.setString(3, desc);
                stmt.setString(4, status);
                stmt.setString(5, edv);
                stmt.setString(6, badgeCode);
                stmt.setString(7, locAccess);
                stmt.setString(8, idTerceirizado);
                stmt.executeUpdate();
                stmt.close();
                bd.conexao.close();
            } catch (SQLException e) {
                System.out.println(e);
            }
        }
    }
}
