/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package SRC;

import CONEXAO_BANCO.Banco_dados;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.sql.PreparedStatement;

/**
 *
 * @author sil9jvl
 */
public class main extends javax.swing.JDialog {

   String pw = new String();
    /**
     * Creates new form Login
     */
    public main(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        placeholder_login();
        SwingUtilities.invokeLater(() -> jLGuy.requestFocusInWindow());
    }
    
    Banco_dados bd = new Banco_dados();
    private void login(){
        if(bd.getConnection()){
            try{
                String query = "SELECT * FROM user where usernameUser = ? and passwordUser = ?";
                PreparedStatement stmt = bd.conexao.prepareStatement(query);
                
                //Atribui os valores digitados
                stmt.setString(1, jTEDV.getText());
                stmt.setString(2, jTPassword.getText());
            } catch(SQLException e){
                JOptionPane.showMessageDialog(null, "Erro"+ e.toString());
            }
        }
    }   
 
    private void placeholder_login() {
        jTEDV.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (jTEDV.getText().equals("EDV")) {
                    jTEDV.setText("");
                    jTEDV.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (jTEDV.getText().isEmpty()) {
                    jTEDV.setText("EDV");
                    jTEDV.setForeground(new Color(204,204,204));
                }
            }
        });

        jTPassword.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (jTPassword.getText().equals("Password")) {
                    jTPassword.setText("");
                    jTPassword.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (jTPassword.getText().isEmpty()) {
                    jTPassword.setText("Password");
                    jTPassword.setForeground(new Color(204,204,204));
                }
            }
        });


    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pwBKP = new javax.swing.JLabel();
        jPLogin = new javax.swing.JPanel();
        jPBox = new javax.swing.JPanel();
        jTEDV = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jTPassword = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLGuy = new javax.swing.JLabel();
        jPHeader = new javax.swing.JPanel();
        header = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(224, 226, 229));
        setLocationByPlatform(true);
        setMaximumSize(new java.awt.Dimension(1160, 720));
        setMinimumSize(new java.awt.Dimension(1160, 720));
        setPreferredSize(new java.awt.Dimension(1160, 720));
        setResizable(false);

        jPLogin.setBackground(new java.awt.Color(224, 226, 229));
        jPLogin.setMaximumSize(new java.awt.Dimension(0, 0));
        jPLogin.setMinimumSize(new java.awt.Dimension(0, 0));
        jPLogin.setPreferredSize(new java.awt.Dimension(0, 0));

        jPBox.setBackground(new java.awt.Color(255, 255, 255));

        jTEDV.setFont(new java.awt.Font("Bosch Sans", 0, 14)); // NOI18N
        jTEDV.setForeground(new java.awt.Color(204, 204, 204));
        jTEDV.setText("EDV");
        jTEDV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTEDVActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Bosch Sans", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("Forgot your password?");

        jButton1.setBackground(new java.awt.Color(0, 62, 100));
        jButton1.setFont(new java.awt.Font("Bosch Sans", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Login");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTPassword.setForeground(new java.awt.Color(204, 204, 204));
        jTPassword.setText("Password");
        jTPassword.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                jTPasswordCaretUpdate(evt);
            }
        });
        jTPassword.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
                jTPasswordCaretPositionChanged(evt);
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                jTPasswordInputMethodTextChanged(evt);
            }
        });
        jTPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTPasswordActionPerformed(evt);
            }
        });
        jTPassword.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTPasswordKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTPasswordKeyTyped(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGES/pw1.png"))); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout jPBoxLayout = new javax.swing.GroupLayout(jPBox);
        jPBox.setLayout(jPBoxLayout);
        jPBoxLayout.setHorizontalGroup(
            jPBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPBoxLayout.createSequentialGroup()
                .addContainerGap(54, Short.MAX_VALUE)
                .addGroup(jPBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPBoxLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(86, 86, 86))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPBoxLayout.createSequentialGroup()
                        .addGroup(jPBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTEDV)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)))
                .addGap(26, 26, 26))
        );
        jPBoxLayout.setVerticalGroup(
            jPBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPBoxLayout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(jTEDV, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(34, 34, 34)
                .addComponent(jLabel1)
                .addGap(63, 63, 63)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(114, Short.MAX_VALUE))
        );

        jLGuy.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGES/guy.png"))); // NOI18N

        javax.swing.GroupLayout jPLoginLayout = new javax.swing.GroupLayout(jPLogin);
        jPLogin.setLayout(jPLoginLayout);
        jPLoginLayout.setHorizontalGroup(
            jPLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPLoginLayout.createSequentialGroup()
                .addContainerGap(367, Short.MAX_VALUE)
                .addComponent(jPBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLGuy)
                .addGap(79, 79, 79))
        );
        jPLoginLayout.setVerticalGroup(
            jPLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPLoginLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(jPLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLGuy)
                    .addComponent(jPBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(130, Short.MAX_VALUE))
        );

        jPHeader.setBackground(new java.awt.Color(224, 226, 229));
        jPHeader.setMaximumSize(new java.awt.Dimension(0, 0));
        jPHeader.setPreferredSize(new java.awt.Dimension(0, 0));

        header.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGES/header-bosch.png"))); // NOI18N
        header.setMaximumSize(new java.awt.Dimension(0, 0));
        header.setMinimumSize(new java.awt.Dimension(0, 0));
        header.setPreferredSize(new java.awt.Dimension(0, 0));

        javax.swing.GroupLayout jPHeaderLayout = new javax.swing.GroupLayout(jPHeader);
        jPHeader.setLayout(jPHeaderLayout);
        jPHeaderLayout.setHorizontalGroup(
            jPHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(header, javax.swing.GroupLayout.DEFAULT_SIZE, 1160, Short.MAX_VALUE)
        );
        jPHeaderLayout.setVerticalGroup(
            jPHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPHeaderLayout.createSequentialGroup()
                .addComponent(header, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 1160, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(jPLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 1160, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPLogin, 630, 630, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTEDVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTEDVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTEDVActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTPasswordActionPerformed

    private void jTPasswordInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_jTPasswordInputMethodTextChanged
     
    }//GEN-LAST:event_jTPasswordInputMethodTextChanged

    private void jTPasswordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTPasswordKeyPressed
    
        
        
    }//GEN-LAST:event_jTPasswordKeyPressed

    private void jTPasswordKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTPasswordKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTPasswordKeyTyped

    private void jTPasswordCaretPositionChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_jTPasswordCaretPositionChanged
        
    }//GEN-LAST:event_jTPasswordCaretPositionChanged

    private void jTPasswordCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_jTPasswordCaretUpdate
        pwBKP.setText(jTPassword.getText());
    }//GEN-LAST:event_jTPasswordCaretUpdate

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                main dialog = new main(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel header;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLGuy;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPBox;
    private javax.swing.JPanel jPHeader;
    private javax.swing.JPanel jPLogin;
    private javax.swing.JTextField jTEDV;
    private javax.swing.JTextField jTPassword;
    private javax.swing.JLabel pwBKP;
    // End of variables declaration//GEN-END:variables
}
