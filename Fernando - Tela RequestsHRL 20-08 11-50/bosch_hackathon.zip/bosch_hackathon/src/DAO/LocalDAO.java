/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import OBJECTS.Local;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author olf5jvl
 */
public interface LocalDAO {
    Local getLocal(int id);
    void asignLocals(String badgeCode,String[] locals);
    void loadLocTable(DefaultTableModel table);
}
