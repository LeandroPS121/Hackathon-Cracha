/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import CONEXAO_BANCO.Banco_dados;
import OBJECTS.Chamado;
import OBJECTS.Terceirizado;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author olf5jvl
 */
public class ChamadoDAOImpl implements ChamadoDAO {

    Banco_dados bd = new Banco_dados();

    /**
     *
     * @param edv
     * @param badgeCode
     * @param expTime
     * @param type
     * @param desc
     * @param status
     * @param locAccess
     * @param idTerceirizado
     */
    @Override
    public void sendChamado(String edv, String badgeCode, int expTime, String type, String desc, String status, String locAccess, String idTerceirizado) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        LocalDateTime agora = LocalDateTime.now();

        String agoraFormated = agora.format(formatter);

        LocalDateTime novaDataHora = agora.plus(expTime, ChronoUnit.YEARS);
        if (edv != null) {
            novaDataHora = agora.plus(expTime, ChronoUnit.HOURS);
        }

        String expDataHoraFormatada = novaDataHora.format(formatter);

        String query = "INSERT INTO chamado ("
                + "dataChamado,tipoChamado,descricaoChamado,statusChamado,edvChamado,crachaSelecionadoChamado,locaisSelecionadoChamado,fk_idTerceirizado,dataExpiracaoChamado)"
                + " VALUES (?,?,?,?,?,?,?,?,?)";

        if (bd.getConnection()) {
            try (PreparedStatement stmt = bd.conexao.prepareStatement(query)) {
                stmt.setString(1, agoraFormated);
                stmt.setString(2, type);
                stmt.setString(3, desc);
                stmt.setString(4, status);
                stmt.setString(5, edv);
                stmt.setString(6, badgeCode);
                stmt.setString(7, locAccess);
                stmt.setString(8, idTerceirizado);
                stmt.setString(9, expDataHoraFormatada);
                stmt.executeUpdate();
                stmt.close();
                bd.conexao.close();
            } catch (SQLException e) {
                System.out.println(e);
            }
        }
    }

    /**
     *
     * @param table
     */
    @Override
    public void loadChamadosFcm(DefaultTableModel table) {
        String query = "SELECT c.idChamado,c.dataChamado,t.nomeCompletoTerceirizado,t.cpfTerceirizado FROM chamado AS c INNER JOIN terceirizado AS t ON c.fk_idTerceirizado = t.idTerceirizado where statusChamado = ?";
        if (bd.getConnection()) {
            try (PreparedStatement stmt = bd.conexao.prepareStatement(query)) {
                stmt.setString(1, "PENDING");
                ResultSet rs = stmt.executeQuery();
                table.setRowCount(0);
                while (rs.next()) {

                    table.addRow(new Object[]{
                        rs.getString("c.idChamado"),
                        rs.getString("c.dataChamado"),
                        rs.getString("t.nomeCompletoTerceirizado"),
                        rs.getString("t.cpfTerceirizado")
                    });
                }

            } catch (SQLException e) {
                System.out.println(e);
            }
        }
    }

    public void updateStatusChamadoFcm(int id) {
        String query = "UPDATE chamado SET statusChamado = ? WHERE idChamado = ?";
        if (bd.getConnection()) {
            try (PreparedStatement stmt = bd.conexao.prepareStatement(query)) {
                stmt.setInt(1, id);
                ResultSet rs = stmt.executeQuery();

            } catch (SQLException e) {
                System.out.println(e);
            }
        }

    }
}
