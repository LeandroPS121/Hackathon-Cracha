/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package main;

import CONEXAO_BANCO.Banco_dados;
import com.toedter.calendar.JDateChooser;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author sil9jvl
 */
public class main extends javax.swing.JDialog {

    private final char[] senha = new char[0]; // armazena a senha como um array de caracteres
    private final boolean senhaVisivel = false; // flag para indicar se a senha está visíve
    ImageIcon iconUnhided = new ImageIcon(getClass().getResource("/main/resources/IMAGES/pw2.png"));
    ImageIcon iconHided = new ImageIcon(getClass().getResource("/main/resources/IMAGES/pw1.png"));

    /**
     * Creates new form Login
     */
    public main(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        
        initComponents();
        placeholder_login();
        SwingUtilities.invokeLater(() -> jLGuy.requestFocusInWindow());
        jTEDV.setHorizontalAlignment(SwingConstants.CENTER);
        jTPassword.setHorizontalAlignment(SwingConstants.CENTER);
        jLHideUnhide.setVisible(true);
        jLUserOrPwError.setVisible(false);
        change_panel(jPHomeHrl, jPLogin);
        init_header();
    }
    
 

    Banco_dados bd = new Banco_dados();

    private void login() {
        if (bd.getConnection()) {
            try {
                String query = "SELECT c.edvColaborador,u.isFcmUser FROM user as u INNER JOIN"
                        + " colaborador as c on c.idColaborador=u.fk_idColaborador where c.edvColaborador = ? and u.passwordUser = ?";
                PreparedStatement stmt = bd.conexao.prepareStatement(query);
                String pwr = String.valueOf(jTPassword.getPassword());
                stmt.setString(1, jTEDV.getText());
                stmt.setString(2, pwr);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    JOptionPane.showMessageDialog(null, "LOGADO!");
                    if (rs.getInt("u.isFcmUser") == 0) {
                        change_panel(jPLogin, jPHomeHrl);
                        lateral_menu();
                        // Get a reference to the JPanel
                    } else {

                    }
                } else {
                    change_panel(jPLogin, jPHomeHrl);
                    jLUserOrPwError.setVisible(true);
                    lateral_menu();
                }
                stmt.close();
                bd.conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro" + e.toString());
            }
        }
    }
    
 
   
    public void lateral_menu(){
             
        //ta aberto e vai fechar
        if(jPMenuLateralHrl.getWidth() > 100){
            
            jPMenuLateralHrl.setSize(jPMenuLateralHrl.getWidth()-175,jPMenuLateralHrl.getHeight());
            jPMenuLateralHrl.setLocation(jPMenuLateralHrl.getX()+175,jPMenuLateralHrl.getY());
            jBRequestHrl.setSize(0,0);
            jBHistoryHrl.setSize(0,0);
            jTBManageHomeHrl.setSize(0,0);
            System.out.println(jBHistoryHrl.getWidth());
            jBRequestHrl.setLocation(915,386);
            jBHistoryHrl.setLocation(915,457);
            jTBManageHomeHrl.setLocation(915,237);
            jPButtonsManageHomeHrl.setLocation(1500,395);
            System.out.println("teste1");
            
            
            
        }else{
            System.out.println("teste2");
            jPMenuLateralHrl.setSize(jPMenuLateralHrl.getWidth()+175,jPMenuLateralHrl.getHeight());
            jPMenuLateralHrl.setLocation(jPMenuLateralHrl.getX()-175,jPMenuLateralHrl.getY());
            //ta fechado e vai abri
            jTBManageHomeHrl.setSize(191,31);
            jBHistoryHrl.setSize(191,31);
            jBRequestHrl.setSize(191,31);
                 jTBManageHomeHrl.setLocation(915,370);
            jBRequestHrl.setLocation(915,420);
            jBHistoryHrl.setLocation(915,470);
            jPButtonsManageHomeHrl.setLocation(636,395);
            System.out.println(jBRequestHrl.getX());
            
            
        }
    }

    private void change_panel(javax.swing.JPanel anterior, javax.swing.JPanel novo) {
        anterior.setVisible(false);
        novo.getParent().setLayout(null);
        novo.setLocation(0,90);
        novo.setVisible(true);
        validate();
        repaint();
    }
    
    private void init_header(){
        jPHeader.getParent().setLayout(null);
        jPHeader.setLocation(0, 0);
    }

    // Cria o painel e o botão
    public void show_input_calendar() {
        JPanel calendarPanel = new JPanel();
        calendarPanel.setLayout(new FlowLayout());

// Create a text field to display the selected date
        JTextField dateField = new JTextField(10);
        JDateChooser dateChooser = new JDateChooser();
        dateChooser.setDateFormatString("dd/MM/yyyy");
        Dimension size = new Dimension(200, 30);
        dateChooser.setPreferredSize(size);
        dateChooser.setMinimumSize(size);
        dateChooser.setMaximumSize(size);

        // Create a panel for the date chooser
        JPanel datePanel = new JPanel();
        datePanel.add(dateChooser);

        // Show the date chooser in a dialog
        int option = JOptionPane.showConfirmDialog(null, datePanel, "Select Date", JOptionPane.OK_CANCEL_OPTION);

        // If the user clicked OK, get the selected date and display it in the text field
        if (option == JOptionPane.OK_OPTION) {
            Date selectedDate = dateChooser.getDate();
            System.out.println("clickou");
            if (selectedDate != null) {

                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                String formattedDate = sdf.format(selectedDate);
                dateField.setText(formattedDate);
                System.out.println("texto:" + formattedDate);
            } else {
                System.out.println("ta vazio nengue");
                show_input_calendar();
            }
        }
        calendarPanel.add(dateField);

// Add the calendar panel to the jPHistoryHrl panel
        jPHistoryHrl.add(calendarPanel);
    }

    private void placeholder_login() {
        jTEDV.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (jTEDV.getText().equals("EDV")) {
                    jTEDV.setText("");
                    jTEDV.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (jTEDV.getText().isEmpty()) {
                    jTEDV.setText("EDV");
                    jTEDV.setForeground(new Color(204, 204, 204));
                }
            }
        });

        jTPassword.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                jLUserOrPwError.setVisible(false);
                String pwrd = String.valueOf(jTPassword.getPassword());
                System.out.println("pwrd" + pwrd);
                if (pwrd.equals("Password")) {
                    jTPassword.setText("");
                    jTPassword.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (jTPassword.getPassword().length == 0 || jTPassword.getPassword() == null) {
                    jTPassword.setText("Password");
                    jTPassword.setForeground(new Color(204, 204, 204));
                }
            }
        });

    }
    
    

    private void atualizarCampoSenha() {
        if (senhaVisivel) {
            jTPassword.setText(new String(senha));
        } else {
            jTPassword.setText(new String(new char[senha.length]).replace("\0", "*"));
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPLogin = new javax.swing.JPanel();
        jPBox = new javax.swing.JPanel();
        jTEDV = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLHideUnhide = new javax.swing.JLabel();
        jTPassword = new javax.swing.JPasswordField();
        jPanel2 = new javax.swing.JPanel();
        jLUserOrPwError = new javax.swing.JLabel();
        jLGuy = new javax.swing.JLabel();
        jPHeader = new javax.swing.JPanel();
        header = new javax.swing.JLabel();
        jPHistoryHrl = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jBAllHistoryHrl = new javax.swing.JToggleButton();
        jBCompletedHistoryHrl = new javax.swing.JToggleButton();
        jBPendingHistoryHrl = new javax.swing.JToggleButton();
        jBCanceledHistoryHrl = new javax.swing.JToggleButton();
        jBCalendarHistoryHrl = new javax.swing.JButton();
        jBCanceledHistoryHrl1 = new javax.swing.JToggleButton();
        jPHomeHrl = new javax.swing.JPanel();
        jPMenuLateralHrl = new javax.swing.JPanel();
        jBAbrirMenuLateralHrl = new javax.swing.JButton();
        jBRequestHrl = new javax.swing.JButton();
        jBHistoryHrl = new javax.swing.JButton();
        jTBManageHomeHrl = new javax.swing.JToggleButton();
        jPButtonsManageHomeHrl = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPTemporaryHrl = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jTEDVorNameSearchHrl = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jSToggleSearchHrl = new javax.swing.JSlider();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jTMessageSearchHrl = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jToggleButton1 = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(224, 226, 229));
        setMaximumSize(new java.awt.Dimension(1160, 720));
        setMinimumSize(new java.awt.Dimension(1160, 720));
        setName("mainDialog"); // NOI18N
        setPreferredSize(new java.awt.Dimension(1160, 720));
        setResizable(false);

        jPLogin.setBackground(new java.awt.Color(224, 226, 229));
        jPLogin.setMaximumSize(new java.awt.Dimension(0, 0));
        jPLogin.setMinimumSize(new java.awt.Dimension(0, 0));
        jPLogin.setPreferredSize(new java.awt.Dimension(0, 0));
        jPLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPLoginMouseClicked(evt);
            }
        });

        jPBox.setBackground(new java.awt.Color(255, 255, 255));
        jPBox.setMaximumSize(new java.awt.Dimension(0, 0));
        jPBox.setPreferredSize(new java.awt.Dimension(0, 0));

        jTEDV.setFont(new java.awt.Font("Bosch Sans", 0, 14)); // NOI18N
        jTEDV.setForeground(new java.awt.Color(204, 204, 204));
        jTEDV.setText("EDV");
        jTEDV.setMaximumSize(new java.awt.Dimension(0, 0));
        jTEDV.setMinimumSize(new java.awt.Dimension(0, 0));
        jTEDV.setPreferredSize(new java.awt.Dimension(0, 0));
        jTEDV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTEDVActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Bosch Sans", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("Forgot your password?");

        jButton1.setBackground(new java.awt.Color(0, 62, 100));
        jButton1.setFont(new java.awt.Font("Bosch Sans", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Login");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(0, 0));
        jPanel1.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(0, 0));

        jLHideUnhide.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/resources/IMAGES/pw1.png"))); // NOI18N
        jLHideUnhide.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLHideUnhide.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLHideUnhideMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLHideUnhide, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLHideUnhide, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTPassword.setForeground(new java.awt.Color(204, 204, 204));
        jTPassword.setText("Password");
        jTPassword.setMaximumSize(new java.awt.Dimension(0, 0));
        jTPassword.setMinimumSize(new java.awt.Dimension(0, 0));
        jTPassword.setPreferredSize(new java.awt.Dimension(0, 0));
        jTPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTPasswordActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setMaximumSize(new java.awt.Dimension(0, 0));
        jPanel2.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel2.setPreferredSize(new java.awt.Dimension(0, 0));

        jLUserOrPwError.setBackground(new java.awt.Color(255, 51, 51));
        jLUserOrPwError.setForeground(new java.awt.Color(255, 0, 51));
        jLUserOrPwError.setText("Incorrect username or password");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(jLUserOrPwError)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 6, Short.MAX_VALUE)
                .addComponent(jLUserOrPwError))
        );

        javax.swing.GroupLayout jPBoxLayout = new javax.swing.GroupLayout(jPBox);
        jPBox.setLayout(jPBoxLayout);
        jPBoxLayout.setHorizontalGroup(
            jPBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPBoxLayout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(jPBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 265, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTPassword, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTEDV, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPBoxLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(101, 101, 101))
        );
        jPBoxLayout.setVerticalGroup(
            jPBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPBoxLayout.createSequentialGroup()
                .addGap(82, 82, 82)
                .addComponent(jTEDV, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(jTPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(64, 64, 64)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(108, Short.MAX_VALUE))
        );

        jLGuy.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/resources/IMAGES/guy.png"))); // NOI18N

        javax.swing.GroupLayout jPLoginLayout = new javax.swing.GroupLayout(jPLogin);
        jPLogin.setLayout(jPLoginLayout);
        jPLoginLayout.setHorizontalGroup(
            jPLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPLoginLayout.createSequentialGroup()
                .addContainerGap(367, Short.MAX_VALUE)
                .addComponent(jPBox, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLGuy)
                .addGap(79, 79, 79))
        );
        jPLoginLayout.setVerticalGroup(
            jPLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPLoginLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(jPLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLGuy)
                    .addComponent(jPBox, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(130, Short.MAX_VALUE))
        );

        jPHeader.setBackground(new java.awt.Color(224, 226, 229));
        jPHeader.setMaximumSize(new java.awt.Dimension(0, 0));
        jPHeader.setPreferredSize(new java.awt.Dimension(0, 0));

        header.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/resources/IMAGES/header-bosch.png"))); // NOI18N
        header.setMaximumSize(new java.awt.Dimension(0, 0));
        header.setMinimumSize(new java.awt.Dimension(0, 0));
        header.setPreferredSize(new java.awt.Dimension(0, 0));

        javax.swing.GroupLayout jPHeaderLayout = new javax.swing.GroupLayout(jPHeader);
        jPHeader.setLayout(jPHeaderLayout);
        jPHeaderLayout.setHorizontalGroup(
            jPHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(header, javax.swing.GroupLayout.DEFAULT_SIZE, 1168, Short.MAX_VALUE)
        );
        jPHeaderLayout.setVerticalGroup(
            jPHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPHeaderLayout.createSequentialGroup()
                .addComponent(header, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPHistoryHrl.setBackground(new java.awt.Color(255, 255, 255));
        jPHistoryHrl.setMaximumSize(new java.awt.Dimension(0, 0));
        jPHistoryHrl.setMinimumSize(new java.awt.Dimension(0, 0));
        jPHistoryHrl.setPreferredSize(new java.awt.Dimension(0, 0));

        jTable1.setFont(new java.awt.Font("Bosch Sans", 0, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Date", "Type", "Description", "STATUS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(2).setResizable(false);
        }

        jBAllHistoryHrl.setBackground(new java.awt.Color(0, 85, 135));
        jBAllHistoryHrl.setFont(new java.awt.Font("Bosch Sans Black", 0, 14)); // NOI18N
        jBAllHistoryHrl.setForeground(new java.awt.Color(255, 255, 255));
        jBAllHistoryHrl.setText("All");

        jBCompletedHistoryHrl.setBackground(new java.awt.Color(0, 85, 135));
        jBCompletedHistoryHrl.setFont(new java.awt.Font("Bosch Sans Black", 0, 14)); // NOI18N
        jBCompletedHistoryHrl.setForeground(new java.awt.Color(255, 255, 255));
        jBCompletedHistoryHrl.setText("Completed");
        jBCompletedHistoryHrl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCompletedHistoryHrlActionPerformed(evt);
            }
        });

        jBPendingHistoryHrl.setBackground(new java.awt.Color(0, 85, 135));
        jBPendingHistoryHrl.setFont(new java.awt.Font("Bosch Sans Black", 0, 14)); // NOI18N
        jBPendingHistoryHrl.setForeground(new java.awt.Color(255, 255, 255));
        jBPendingHistoryHrl.setText("Pending");
        jBPendingHistoryHrl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBPendingHistoryHrlActionPerformed(evt);
            }
        });

        jBCanceledHistoryHrl.setBackground(new java.awt.Color(0, 85, 135));
        jBCanceledHistoryHrl.setFont(new java.awt.Font("Bosch Sans Black", 0, 14)); // NOI18N
        jBCanceledHistoryHrl.setForeground(new java.awt.Color(255, 255, 255));
        jBCanceledHistoryHrl.setText("Canceled");
        jBCanceledHistoryHrl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCanceledHistoryHrlActionPerformed(evt);
            }
        });

        jBCalendarHistoryHrl.setBackground(new java.awt.Color(0, 85, 135));
        jBCalendarHistoryHrl.setFont(new java.awt.Font("Bosch Sans Black", 0, 14)); // NOI18N
        jBCalendarHistoryHrl.setForeground(new java.awt.Color(255, 255, 255));
        jBCalendarHistoryHrl.setText("Search Date");
        jBCalendarHistoryHrl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCalendarHistoryHrlActionPerformed(evt);
            }
        });

        jBCanceledHistoryHrl1.setBackground(new java.awt.Color(0, 85, 135));
        jBCanceledHistoryHrl1.setFont(new java.awt.Font("Bosch Sans Black", 0, 14)); // NOI18N
        jBCanceledHistoryHrl1.setForeground(new java.awt.Color(255, 255, 255));
        jBCanceledHistoryHrl1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/resources/IMAGES/left-icon.png"))); // NOI18N
        jBCanceledHistoryHrl1.setText("Return");
        jBCanceledHistoryHrl1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCanceledHistoryHrl1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPHistoryHrlLayout = new javax.swing.GroupLayout(jPHistoryHrl);
        jPHistoryHrl.setLayout(jPHistoryHrlLayout);
        jPHistoryHrlLayout.setHorizontalGroup(
            jPHistoryHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPHistoryHrlLayout.createSequentialGroup()
                .addGap(205, 205, 205)
                .addGroup(jPHistoryHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 753, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPHistoryHrlLayout.createSequentialGroup()
                        .addComponent(jBCanceledHistoryHrl1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jBCalendarHistoryHrl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBAllHistoryHrl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBCompletedHistoryHrl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBPendingHistoryHrl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBCanceledHistoryHrl)))
                .addContainerGap(202, Short.MAX_VALUE))
        );
        jPHistoryHrlLayout.setVerticalGroup(
            jPHistoryHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPHistoryHrlLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPHistoryHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBCanceledHistoryHrl1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBAllHistoryHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBCompletedHistoryHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBPendingHistoryHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBCanceledHistoryHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBCalendarHistoryHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(89, Short.MAX_VALUE))
        );

        jPHomeHrl.setBackground(new java.awt.Color(255, 255, 255));
        jPHomeHrl.setMaximumSize(new java.awt.Dimension(0, 0));
        jPHomeHrl.setPreferredSize(new java.awt.Dimension(1160, 630));

        jPMenuLateralHrl.setBackground(new java.awt.Color(0, 85, 135));
        jPMenuLateralHrl.setMaximumSize(new java.awt.Dimension(0, 0));
        jPMenuLateralHrl.setPreferredSize(new java.awt.Dimension(0, 0));

        jBAbrirMenuLateralHrl.setBackground(new java.awt.Color(0, 62, 100));
        jBAbrirMenuLateralHrl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/resources/IMAGES/bosch-ic-arrow-double-bold-left-sharp-arc-32px.png"))); // NOI18N
        jBAbrirMenuLateralHrl.setBorderPainted(false);
        jBAbrirMenuLateralHrl.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBAbrirMenuLateralHrl.setOpaque(true);
        jBAbrirMenuLateralHrl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBAbrirMenuLateralHrlActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPMenuLateralHrlLayout = new javax.swing.GroupLayout(jPMenuLateralHrl);
        jPMenuLateralHrl.setLayout(jPMenuLateralHrlLayout);
        jPMenuLateralHrlLayout.setHorizontalGroup(
            jPMenuLateralHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPMenuLateralHrlLayout.createSequentialGroup()
                .addContainerGap(7, Short.MAX_VALUE)
                .addComponent(jBAbrirMenuLateralHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPMenuLateralHrlLayout.setVerticalGroup(
            jPMenuLateralHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPMenuLateralHrlLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jBAbrirMenuLateralHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(585, Short.MAX_VALUE))
        );

        jBRequestHrl.setBackground(new java.awt.Color(0, 110, 173));
        jBRequestHrl.setFont(new java.awt.Font("Bosch Sans", 0, 18)); // NOI18N
        jBRequestHrl.setForeground(new java.awt.Color(255, 255, 255));
        jBRequestHrl.setText("Requests");
        jBRequestHrl.setMaximumSize(new java.awt.Dimension(91, 31));
        jBRequestHrl.setMinimumSize(new java.awt.Dimension(0, 0));
        jBRequestHrl.setPreferredSize(new java.awt.Dimension(91, 31));
        jBRequestHrl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBRequestHrlActionPerformed(evt);
            }
        });

        jBHistoryHrl.setBackground(new java.awt.Color(0, 110, 173));
        jBHistoryHrl.setFont(new java.awt.Font("Bosch Sans", 0, 18)); // NOI18N
        jBHistoryHrl.setForeground(new java.awt.Color(255, 255, 255));
        jBHistoryHrl.setText("History");
        jBHistoryHrl.setMinimumSize(new java.awt.Dimension(0, 0));
        jBHistoryHrl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBHistoryHrlActionPerformed(evt);
            }
        });

        jTBManageHomeHrl.setBackground(new java.awt.Color(0, 110, 173));
        jTBManageHomeHrl.setFont(new java.awt.Font("Bosch Sans", 0, 18)); // NOI18N
        jTBManageHomeHrl.setForeground(new java.awt.Color(255, 255, 255));
        jTBManageHomeHrl.setText("Manage");
        jTBManageHomeHrl.setMaximumSize(new java.awt.Dimension(0, 0));
        jTBManageHomeHrl.setMinimumSize(new java.awt.Dimension(0, 0));
        jTBManageHomeHrl.setPreferredSize(new java.awt.Dimension(0, 0));
        jTBManageHomeHrl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTBManageHomeHrlActionPerformed(evt);
            }
        });

        jPButtonsManageHomeHrl.setBackground(new java.awt.Color(0, 102, 153));

        jButton3.setBackground(new java.awt.Color(0, 110, 173));
        jButton3.setFont(new java.awt.Font("Bosch Sans", 0, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Assign temporary badge");
        jButton3.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton3.setMaximumSize(new java.awt.Dimension(0, 0));
        jButton3.setMinimumSize(new java.awt.Dimension(0, 0));
        jButton3.setPreferredSize(new java.awt.Dimension(0, 0));

        jButton4.setBackground(new java.awt.Color(0, 110, 173));
        jButton4.setFont(new java.awt.Font("Bosch Sans", 0, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Badge Management");
        jButton4.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton4.setMaximumSize(new java.awt.Dimension(0, 0));
        jButton4.setMinimumSize(new java.awt.Dimension(0, 0));
        jButton4.setPreferredSize(new java.awt.Dimension(0, 0));

        javax.swing.GroupLayout jPButtonsManageHomeHrlLayout = new javax.swing.GroupLayout(jPButtonsManageHomeHrl);
        jPButtonsManageHomeHrl.setLayout(jPButtonsManageHomeHrlLayout);
        jPButtonsManageHomeHrlLayout.setHorizontalGroup(
            jPButtonsManageHomeHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPButtonsManageHomeHrlLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
            .addGroup(jPButtonsManageHomeHrlLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPButtonsManageHomeHrlLayout.setVerticalGroup(
            jPButtonsManageHomeHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPButtonsManageHomeHrlLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPHomeHrlLayout = new javax.swing.GroupLayout(jPHomeHrl);
        jPHomeHrl.setLayout(jPHomeHrlLayout);
        jPHomeHrlLayout.setHorizontalGroup(
            jPHomeHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPHomeHrlLayout.createSequentialGroup()
                .addContainerGap(701, Short.MAX_VALUE)
                .addGroup(jPHomeHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPHomeHrlLayout.createSequentialGroup()
                        .addGroup(jPHomeHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jBHistoryHrl, 0, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jBRequestHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(103, 103, 103)
                        .addComponent(jPButtonsManageHomeHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPHomeHrlLayout.createSequentialGroup()
                        .addComponent(jTBManageHomeHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(372, 372, 372)))
                .addComponent(jPMenuLateralHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPHomeHrlLayout.setVerticalGroup(
            jPHomeHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPHomeHrlLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPMenuLateralHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPHomeHrlLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTBManageHomeHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPHomeHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPHomeHrlLayout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(jBRequestHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jBHistoryHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(113, 113, 113))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPHomeHrlLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPButtonsManageHomeHrl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(105, 105, 105))))
        );

        jPTemporaryHrl.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(239, 241, 242));
        jPanel3.setMaximumSize(new java.awt.Dimension(0, 0));
        jPanel3.setPreferredSize(new java.awt.Dimension(0, 0));

        jTEDVorNameSearchHrl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTEDVorNameSearchHrlActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 110, 173));
        jButton2.setFont(new java.awt.Font("Bosch Sans", 0, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Search");

        jSToggleSearchHrl.setMaximum(1);
        jSToggleSearchHrl.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSToggleSearchHrlStateChanged(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Bosch Sans", 0, 14)); // NOI18N
        jLabel3.setText("Name");

        jLabel4.setFont(new java.awt.Font("Bosch Sans", 0, 14)); // NOI18N
        jLabel4.setText("EDV");

        jTMessageSearchHrl.setText("MSG");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(162, Short.MAX_VALUE)
                .addComponent(jTMessageSearchHrl)
                .addGap(151, 151, 151))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addComponent(jTMessageSearchHrl)
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(55, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(75, 75, 75))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jSToggleSearchHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabel3))
                        .addComponent(jTEDVorNameSearchHrl)
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(39, 39, 39))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jSToggleSearchHrl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTEDVorNameSearchHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(0, 110, 173));
        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Code", "Status", "Actual User"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setResizable(false);
            jTable2.getColumnModel().getColumn(1).setResizable(false);
            jTable2.getColumnModel().getColumn(2).setResizable(false);
        }

        jToggleButton1.setBackground(new java.awt.Color(0, 204, 0));
        jToggleButton1.setFont(new java.awt.Font("Bosch Sans", 1, 18)); // NOI18N
        jToggleButton1.setForeground(new java.awt.Color(255, 255, 255));
        jToggleButton1.setText("Complete");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jToggleButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 526, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(70, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jToggleButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(183, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPTemporaryHrlLayout = new javax.swing.GroupLayout(jPTemporaryHrl);
        jPTemporaryHrl.setLayout(jPTemporaryHrlLayout);
        jPTemporaryHrlLayout.setHorizontalGroup(
            jPTemporaryHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPTemporaryHrlLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 432, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPTemporaryHrlLayout.setVerticalGroup(
            jPTemporaryHrlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPTemporaryHrlLayout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPTemporaryHrlLayout.createSequentialGroup()
                .addGap(0, 6, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 1168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPHistoryHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 1160, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 1160, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(jPHomeHrl, javax.swing.GroupLayout.DEFAULT_SIZE, 1148, Short.MAX_VALUE)
                    .addGap(10, 10, 10)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(4, 4, 4)
                    .addComponent(jPTemporaryHrl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(4, 4, 4)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(654, 654, 654)
                .addComponent(jPHistoryHrl, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1492, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 1115, Short.MAX_VALUE)
                    .addComponent(jPLogin, 630, 630, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 1115, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(2185, 2185, 2185)
                    .addComponent(jPHomeHrl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(45, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(1041, 1041, 1041)
                    .addComponent(jPTemporaryHrl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(1182, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTEDVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTEDVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTEDVActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        login();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jLHideUnhideMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLHideUnhideMouseClicked
        if (jTPassword.getEchoChar() == '*') {
            jTPassword.setEchoChar((char) 0); // mostra a senha
            jLHideUnhide.setIcon(iconUnhided);
        } else {
            jTPassword.setEchoChar('*'); // oculta a senha
            jLHideUnhide.setIcon(iconHided);

        }
    }//GEN-LAST:event_jLHideUnhideMouseClicked

    private void jTPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTPasswordActionPerformed

    private void jPLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPLoginMouseClicked

    }//GEN-LAST:event_jPLoginMouseClicked

    private void jBCanceledHistoryHrl1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCanceledHistoryHrl1ActionPerformed
        change_panel(jPHistoryHrl,jPHomeHrl);
    }//GEN-LAST:event_jBCanceledHistoryHrl1ActionPerformed

    private void jBCalendarHistoryHrlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCalendarHistoryHrlActionPerformed
        show_input_calendar();
    }//GEN-LAST:event_jBCalendarHistoryHrlActionPerformed

    private void jBCanceledHistoryHrlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCanceledHistoryHrlActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jBCanceledHistoryHrlActionPerformed

    private void jBPendingHistoryHrlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBPendingHistoryHrlActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jBPendingHistoryHrlActionPerformed

    private void jBCompletedHistoryHrlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCompletedHistoryHrlActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jBCompletedHistoryHrlActionPerformed

    private void jBRequestHrlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBRequestHrlActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jBRequestHrlActionPerformed

    private void jBHistoryHrlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBHistoryHrlActionPerformed
        change_panel(jPHomeHrl, jPHistoryHrl);
    }//GEN-LAST:event_jBHistoryHrlActionPerformed

    private void jBAbrirMenuLateralHrlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBAbrirMenuLateralHrlActionPerformed
        lateral_menu();
        System.out.println(jPButtonsManageHomeHrl.getLocation());
    }//GEN-LAST:event_jBAbrirMenuLateralHrlActionPerformed

    private void jTEDVorNameSearchHrlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTEDVorNameSearchHrlActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTEDVorNameSearchHrlActionPerformed

    private void jSToggleSearchHrlStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSToggleSearchHrlStateChanged
        jTEDVorNameSearchHrl.setText("");
    }//GEN-LAST:event_jSToggleSearchHrlStateChanged

    private void jTBManageHomeHrlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTBManageHomeHrlActionPerformed
        if (jTBManageHomeHrl.isSelected()){
            jBHistoryHrl.setEnabled(false);
            jBRequestHrl.setEnabled(false);
            jPButtonsManageHomeHrl.setVisible(true);
        }else{
            jBHistoryHrl.setEnabled(true);
            jBRequestHrl.setEnabled(true);
            jPButtonsManageHomeHrl.setVisible(true);
        }
    }//GEN-LAST:event_jTBManageHomeHrlActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                main dialog = new main(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel header;
    private javax.swing.JButton jBAbrirMenuLateralHrl;
    private javax.swing.JToggleButton jBAllHistoryHrl;
    private javax.swing.JButton jBCalendarHistoryHrl;
    private javax.swing.JToggleButton jBCanceledHistoryHrl;
    private javax.swing.JToggleButton jBCanceledHistoryHrl1;
    private javax.swing.JToggleButton jBCompletedHistoryHrl;
    private javax.swing.JButton jBHistoryHrl;
    private javax.swing.JToggleButton jBPendingHistoryHrl;
    private javax.swing.JButton jBRequestHrl;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLGuy;
    private javax.swing.JLabel jLHideUnhide;
    private javax.swing.JLabel jLUserOrPwError;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPBox;
    private javax.swing.JPanel jPButtonsManageHomeHrl;
    private javax.swing.JPanel jPHeader;
    private javax.swing.JPanel jPHistoryHrl;
    private javax.swing.JPanel jPHomeHrl;
    private javax.swing.JPanel jPLogin;
    private javax.swing.JPanel jPMenuLateralHrl;
    private javax.swing.JPanel jPTemporaryHrl;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JSlider jSToggleSearchHrl;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JToggleButton jTBManageHomeHrl;
    private javax.swing.JTextField jTEDV;
    private javax.swing.JTextField jTEDVorNameSearchHrl;
    private javax.swing.JLabel jTMessageSearchHrl;
    private javax.swing.JPasswordField jTPassword;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JToggleButton jToggleButton1;
    // End of variables declaration//GEN-END:variables
}
