/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AUTH.DAO;

import OBJECTS.Access;

/**
 *
 * @author sil9jvl
 */
public interface AccessDAO {
    void addAccess(Access access);
}
